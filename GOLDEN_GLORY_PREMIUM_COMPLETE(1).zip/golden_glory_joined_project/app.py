import os, re, sqlite3, time, secrets
import requests
from cryptography.fernet import Fernet
from flask import Flask, jsonify, request, send_from_directory
app=Flask(__name__,static_folder="static")
API_BASE=os.getenv("FREEFIRE_API_BASE","http://siambhau69.eu.cc").rstrip("/")
API_KEY=os.getenv("FREEFIRE_API_KEY","")
APP_BASE_URL=os.getenv("APP_BASE_URL","").rstrip("/")
BOT_ENCRYPTION_KEY=os.getenv("BOT_ENCRYPTION_KEY","")
DB=os.getenv("BOT_DB_PATH","bots.sqlite3")
REGIONS={"IND","BD","PK","SG","ID","TH","VN","BR","US","NA","ME","EUROPE","RU","CIS","SAC","TW"}
def box():
 if not BOT_ENCRYPTION_KEY: raise RuntimeError("BOT_ENCRYPTION_KEY is not configured")
 return Fernet(BOT_ENCRYPTION_KEY.encode())
def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute("CREATE TABLE IF NOT EXISTS bots(bot_id TEXT PRIMARY KEY,username TEXT,token_enc TEXT,secret TEXT,owner_chat TEXT,created_at INTEGER)");return c
@app.get("/")
def home(): return send_from_directory("static","index.html")
@app.get("/api/health")
def health(): return jsonify({"ok":True,"guild_api_configured":bool(API_KEY),"player_api_configured":bool(API_KEY),"bot_studio_configured":bool(BOT_ENCRYPTION_KEY and APP_BASE_URL)})
def ff(path,params):
 if not API_KEY:return None,(jsonify({"error":"Host admin must set FREEFIRE_API_KEY."}),503)
 try:
  r=requests.get(API_BASE+path,params={**params,"key":API_KEY},timeout=20);d=r.json()
  if r.status_code>=400 or (isinstance(d,dict) and d.get("error")):return None,(jsonify({"error":d.get("error",f"API HTTP {r.status_code}")}),502)
  return d,None
 except (requests.RequestException,ValueError):return None,(jsonify({"error":"Free Fire API unavailable or invalid response."}),502)
@app.get("/api/guild/info")
def guild_info():
 cid=(request.args.get("clan_id") or "3048889605").strip()
 if not cid.isdigit():return jsonify({"error":"Guild ID must be numeric."}),400
 d,e=ff("/guild/info",{"clan_id":cid});return e if e else jsonify(d)
@app.post("/api/player/batch")
def player_batch():
 b=request.get_json(silent=True) or {};uids=b.get("uids",[]);region=str(b.get("region","IND")).upper()
 if not isinstance(uids,list) or not 1<=len(uids)<=4:return jsonify({"error":"Enter 1 to 4 UIDs."}),400
 if region not in REGIONS:return jsonify({"error":"Unsupported region."}),400
 out=[]
 for raw in uids:
  uid=str(raw).strip()
  if not uid.isdigit():out.append({"uid":uid,"error":"UID must contain digits only."});continue
  d,e=ff("/freefireinfo/bhau",{"uid":uid,"region":region})
  if e:out.append({"uid":uid,"error":e[0].get_json().get("error","Lookup failed")});continue
  p=d.get("basicInfo") or d.get("basic_info") or d
  out.append({"uid":uid,"nickname":p.get("nickname",p.get("name","—")),"level":p.get("level"),"likes":p.get("liked",p.get("likes")),"rank":p.get("rankingPoints",p.get("rank")),"region":p.get("region",region)})
 return jsonify({"players":out})
@app.post("/api/bots/connect")
def connect_bot():
 b=request.get_json(silent=True) or {};token=str(b.get("token","")).strip();owner=str(b.get("owner_chat_id","")).strip()
 if not re.fullmatch(r"\d+:[A-Za-z0-9_-]{20,}",token):return jsonify({"error":"Invalid Telegram bot token format."}),400
 if not APP_BASE_URL.startswith("https://"):return jsonify({"error":"Set APP_BASE_URL to your public HTTPS website URL."}),503
 try: f=box()
 except RuntimeError as e:return jsonify({"error":str(e)}),503
 try:
  info=requests.get(f"https://api.telegram.org/bot{token}/getMe",timeout=15).json()
  if not info.get("ok"):return jsonify({"error":"Telegram rejected this token. Check @BotFather."}),400
  bot=info["result"];bid=str(bot["id"]);secret=secrets.token_urlsafe(32);whurl=f"{APP_BASE_URL}/telegram/webhook/{bid}"
  wh=requests.post(f"https://api.telegram.org/bot{token}/setWebhook",data={"url":whurl,"secret_token":secret},timeout=15).json()
  if not wh.get("ok"):return jsonify({"error":wh.get("description","Webhook registration failed")}),502
  c=db();c.execute("INSERT OR REPLACE INTO bots VALUES(?,?,?,?,?,?)",(bid,bot.get("username",""),f.encrypt(token.encode()).decode(),secret,owner,int(time.time())));c.commit();c.close()
  return jsonify({"ok":True,"username":bot.get("username","")})
 except requests.RequestException:return jsonify({"error":"Could not reach Telegram."}),502
@app.post("/telegram/webhook/<bid>")
def webhook(bid):
 c=db();row=c.execute("SELECT * FROM bots WHERE bot_id=?",(bid,)).fetchone();c.close()
 if not row:return jsonify({"ok":False}),404
 if request.headers.get("X-Telegram-Bot-Api-Secret-Token","")!=row["secret"]:return jsonify({"ok":False}),403
 try:token=box().decrypt(row["token_enc"].encode()).decode()
 except Exception:return jsonify({"ok":False}),500
 update=request.get_json(silent=True) or {};msg=update.get("message") or {};chat=(msg.get("chat") or {}).get("id");parts=(msg.get("text") or "").split()
 if not chat:return jsonify({"ok":True})
 cmd=parts[0].split("@")[0].lower() if parts else "";answer="Commands: /guild GUILD_ID, /player UID REGION, /help"
 if cmd in ("/start","/help"):pass
 elif cmd=="/guild" and len(parts)>1 and parts[1].isdigit():
  d,e=ff("/guild/info",{"clan_id":parts[1]});answer=("Guild API error: "+e[0].get_json().get("error")) if e else "Guild: "+str(d.get("clan_name","—"))+"\nLevel: "+str(d.get("level","—"))+"\nScore: "+str(d.get("score","—"))
 elif cmd=="/player" and len(parts)>1 and parts[1].isdigit():
  reg=parts[2].upper() if len(parts)>2 else "IND";d,e=ff("/freefireinfo/bhau",{"uid":parts[1],"region":reg});p=(d.get("basicInfo") or {}) if not e else {};answer=("Player API error: "+e[0].get_json().get("error")) if e else f"Player: {p.get('nickname','—')}\nLevel: {p.get('level','—')}\nLikes: {p.get('liked','—')}"
 try:requests.post(f"https://api.telegram.org/bot{token}/sendMessage",json={"chat_id":chat,"text":answer},timeout=12)
 except requests.RequestException:pass
 return jsonify({"ok":True})
if __name__=="__main__":app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")))
